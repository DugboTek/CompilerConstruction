class BadEight
{
    public static void main(String[] a)
    {
        boolean value;
        value = false;
        System.out.println(value);
    }
}


