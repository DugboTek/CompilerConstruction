class BadNine
{
    public static void main(String[] a)
    {
        System.out.println(a[0]]);
    }
}


