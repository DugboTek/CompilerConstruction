class BadSix
{
    public static void main(String[] a)
    {
        System.out.println(new Internal().Run(0));
    }
}

class Internal
{
    public int[] Run(int x)
    {
        return int[];
    }
}
