class BadOne
{
    public static void main(String a[])
    {
        System.out.println(0);
    }
}


