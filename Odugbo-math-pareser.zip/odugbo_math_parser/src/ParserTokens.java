// Output created by jacc on Tue Feb 27 15:05:16 EST 2024

interface ParserTokens {
    int ENDINPUT = 0;
    int ADDOP = 1;
    int DIVOP = 2;
    int DOUBLEOP = 3;
    int LPAREN = 4;
    int MULOP = 5;
    int NUMBER = 6;
    int RPAREN = 7;
    int SUBOP = 8;
    int UNKNOWN = 9;
    int error = 10;
}
