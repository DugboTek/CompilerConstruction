/**
 * 
 */
/**
 * 
 */
module odugbo_math_scanner {
	exports odugbo_math_scanner;
}